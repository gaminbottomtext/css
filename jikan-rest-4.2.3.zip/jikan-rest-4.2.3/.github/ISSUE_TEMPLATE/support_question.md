---
name: "\U0001F917 Support Question"
about: "If you have a question \U0001F4AC, please check out our discord server!"
title: ''
labels: 'i: question, i: needs triage'
assignees: ''
---

--------------^ Click "Preview" for a nicer view!
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks! 😁.

---

* Discord: [![Discord Server](https://img.shields.io/discord/460491088004907029.svg?style=flat&logo=discord)](https://discordapp.com/invite/4tvCr36)
* Have a look at the readme for more information on how to get support:
  https://github.com/jikan-me/jikan-rest/blob/master/README.md
* Container usage for self hosters: https://github.com/jikan-me/jikan-rest/blob/master/container_usage.md
