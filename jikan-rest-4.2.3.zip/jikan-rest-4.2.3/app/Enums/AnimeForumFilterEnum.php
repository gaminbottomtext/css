<?php

namespace App\Enums;

use Spatie\Enum\Laravel\Enum;

/**
 * @method static self all()
 * @method static self episode()
 * @method static self other()
 */
final class AnimeForumFilterEnum extends Enum
{
}
