<?php

namespace App\Enums;


use Spatie\Enum\Laravel\Enum;

/**
 * @method static self all()
 * @method static self chapters()
 * @method static self other()
 */
final class MangaForumFilterEnum extends Enum
{
}
