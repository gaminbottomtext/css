<?php

namespace App\Contracts;

use App\Producers;

/**
 * @implements Repository<Producers>
 */
interface ProducerRepository extends Repository
{

}
