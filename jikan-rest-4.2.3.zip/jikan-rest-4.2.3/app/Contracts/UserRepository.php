<?php

namespace App\Contracts;

use App\Profile;

/**
 * @implements Repository<Profile>
 */
interface UserRepository extends Repository
{
}
