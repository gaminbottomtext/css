<?php

namespace App\Contracts;

use App\Magazine;

/**
 * @implements Repository<Magazine>
 */
interface MagazineRepository extends Repository
{
}
