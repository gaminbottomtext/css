<?php

namespace App\Contracts;

use App\Club;

/**
 * @implements Repository<Club>
 */
interface ClubRepository extends Repository
{
}
