<?php

namespace App\Exceptions\Console;

class FileNotFoundException extends \Exception
{

}