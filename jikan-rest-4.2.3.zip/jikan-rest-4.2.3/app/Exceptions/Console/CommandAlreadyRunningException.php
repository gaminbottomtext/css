<?php

namespace App\Exceptions\Console;

class CommandAlreadyRunningException extends \Exception
{

}