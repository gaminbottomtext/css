<?php

namespace App\Exceptions;

/**
 * @codeCoverageIgnore
 */
class CustomTestException extends \Exception
{
}
