<?php

namespace App\Dto;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * @extends LookupDataCommand<JsonResponse>
 */
final class AnimeLookupCommand extends LookupDataCommand
{
}
