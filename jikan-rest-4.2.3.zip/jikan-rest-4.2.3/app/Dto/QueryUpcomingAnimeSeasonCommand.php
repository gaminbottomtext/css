<?php

namespace App\Dto;

final class QueryUpcomingAnimeSeasonCommand extends QueryAnimeSeasonCommand
{
}
