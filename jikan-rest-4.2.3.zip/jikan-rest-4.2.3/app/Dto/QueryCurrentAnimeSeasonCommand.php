<?php

namespace App\Dto;


final class QueryCurrentAnimeSeasonCommand extends QueryAnimeSeasonCommand
{
}
